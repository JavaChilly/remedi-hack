module.exports = {
	'node': { 'port': '8200' },
	'mongo' :  
	{ 
		'name'	   : 'test',
		'database' : 'test', 
		'address' : 'localhost',
		'port'     : 27017
	}
};